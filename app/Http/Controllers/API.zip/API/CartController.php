<?php

namespace App\Http\Controllers\API;
use App\Models\CartAddition;
use App\Models\City;
use App\Models\Setting;

use App\Models\Order;
use App\Models\OrderProduct;

use App\Models\Cart;
use App\Models\Product;

use App\Models\Rate;
use App\Models\PromotionCode;
use App\Notifications\ResetPassword;
use Carbon\Carbon;
use Illuminate\Support\Facades\Password;
use App\User;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use App\Models\Token;
use App\Models\NotificationMessage;

use Illuminate\Support\Facades\Validator;
use Image;
use DB;


class CartController extends Controller
{
    public function image_extensions()
    {
        return array('jpg', 'png', 'jpeg', 'gif', 'bmp');
    }


    public function addProductToCart(Request $request){
//        if($request->header('fcm_token') == 0){
//            return response()->json(['status' => false, 'code' => 202 ,'message' =>  'Not found Fcm_token'  ]);
//        }

        $valid = Validator::make($request->all(),[
            'product_id'=>'required',
        ]);

        if ($valid->fails()) {
            return mainResponse(false, '', null, 200, 'items', $valid);
        }

        $myCartProduct = Cart::where('fcm_token', '=', $request->header('fcm_token'))->where('product_id',$request->product_id )->first();
        if($myCartProduct){
            $message = __('api.sameCart');
            return response()->json(['status' => false, 'code' => 200, 'message' =>  $message]);
        }

        $myCart = new Cart();
        if(Auth::check()){
            $myCart->user_id = auth('api')->id();
          }
            $myCart->fcm_token = $request->header('fcm_token');
            $myCart->product_id = $request->product_id;
            $price_type=Product::findOrFail($request->product_id);
            
            /*if($price_type->type == 0)
            {
                $price_type1 = 1;
            }
            else if($price_type->type == 1)
            {
                $price_type1 = 1;
            }
            else
            {
                $price_type1 = 1;
            }*/
        
            $price_type1 = 1;
            $myCart->quantity = $price_type1;//($price_type->type == 0)? 0.25: 1;


            $myCart->save();
            //$count_products=Cart::where('fcm_token', $request->header('fcm_token'))->count();
            $myNewCart = Cart::where('fcm_token', '=', $request->header('fcm_token'))->with('product')->get();
            $count_products = count($myNewCart);
        
            $total_cart = 0;
            foreach($myNewCart as $one) {
                $price_val =  ($one->product->price_offer)? $one->product->price_offer:$one->product->price;
                $total_cart +=$price_val * $one->quantity;
            }

            $message = __('api.add_cart');
            return response()->json(['status' => true, 'code' => 200, 'message' => $message , 'count_products'=>$count_products, 'total_cart'=>$total_cart]);
        }


    public function getMyCart(Request $request)
    {

        $myCart = Cart::where('fcm_token', '=', $request->header('fcm_token'))->with('product')->get();
        if ($myCart) {
            //return $myCartProduct;
            $message = __('api.ok');
            return response()->json(['status' => true, 'code' => 200, 'message' => $message, 'MyCart' => $myCart]);
        }
        $message = __('api.cartEmpty');
        return response()->json(['status' => true, 'code' => 200, 'message' => $message]);

    }

    public function changeQuantity(Request $request)
    {

        $rules = [
            'product_id' => 'required',
            'type' => 'required',
        ];
        $this->validate($request, $rules);

        $myCart = Cart::where('fcm_token', '=', $request->header('fcm_token'))->where('product_id',$request->product_id)->with('product')->first();
        $product=Product::findOrFail($request->product_id);
        
        if($product->type == 0)  // kg
        {
            $price_type = 0.5;
        }
        elseif($product->type == 1 || $product->type == 2 || $product->type == 3 || $product->type == 4 || $product->type == 5)
        {
            $price_type = 1;
        }
       /* else
        {
            $price_type = 1;
        }*/
        
        
        //$price_type = ($product->type == 0)? 0.25: 1;
        if ($myCart) {
            if ($request->type == 1) {
                $newValue = $myCart->quantity + $price_type ;
                $myCart->update(['quantity'=>$newValue]);
                $message = __('api.ok');
                return response()->json(['status' => true, 'code' => 200, 'message' => $message, 'Quantity' => $newValue ]);
            }
            else if ($request->type == 0 && $myCart->quantity >= $price_type) {
                $newValue = $myCart->quantity - $price_type;
                $myCart->update(['quantity'=>$newValue]);
                if($myCart->quantity <= 0){

                    Cart::where('fcm_token', '=', $request->header('fcm_token'))->where('product_id',$request->product_id)->delete();
                    $message = __('api.ok');
                    return response()->json(['status' => true, 'code' => 200, 'message' => 'product deleted']);
                }
                $message = __('api.ok');
                return response()->json(['status' => true, 'code' => 200, 'message' => $message, 'Quantity' => $newValue ]);
            }
            else if ($request->type == 2 && $myCart->quantity >= $price_type) {
                $newValue = $myCart->quantity - $price_type;
                $myCart->update(['quantity'=>$newValue]);
                if($myCart->quantity <= 0){

                    Cart::where('fcm_token', '=', $request->header('fcm_token'))->where('product_id',$request->product_id)->delete();
                    $message = __('api.ok');
                    return response()->json(['status' => true, 'code' => 200, 'message' => 'product deleted']);
                }
                $message = __('api.ok');
                return response()->json(['status' => true, 'code' => 200, 'message' => $message, 'Quantity' => $newValue ]);
            }
            else  {
                $message = __('api.not_found');
                return response()->json(['status' => true, 'code' => 200, 'message' => $message]);
            }
        }
        else {
            $message = __('api.not_found');
            return response()->json(['status' => true, 'code' => 200, 'message' => $message]);
        }
    }

    public function deleteProductCart(Request $request,$product_id){
        $myCart = Cart::where('fcm_token', '=', $request->header('fcm_token'))->where('product_id',$product_id)->delete();

        if($myCart){
            
            $myNewCart = Cart::where('fcm_token', '=', $request->header('fcm_token'))->with('product')->get();
            $total_cart = 0;
            foreach($myNewCart as $one) {
                $price_val =  ($one->product->price_offer)? $one->product->price_offer:$one->product->price;
                $total_cart +=$price_val * $one->quantity;
            }
            
            $message = __('api.ok');
            return response()->json(['status' => true, 'code' => 200, 'message' => $message, 'total_cart'=>$total_cart]);
        }else{
            $message = __('api.not_found');
            return response()->json(['status' => true, 'code' => 200, 'message' => $message]);
        }

    }

    public function checkOut(Request $request){
        
       $setting_minOrder=Setting::query()->first();
       
       if((strtotime($setting_minOrder->from_hour) <= strtotime(date('H:i:s'))) && (strtotime($setting_minOrder->to_hour) >= strtotime(date('H:i:s')) ) )
       {
           
       $user_id = auth('api')->id();
       $user=user::findOrFail($user_id);
       $mobile=$user->mobile;

        $valid = Validator::make($request->all(),[
            'delivery_address' => 'required',
            'delivery_city_id' => 'required',
            'mobile' => 'required',
        ]);

        if ($valid->fails()) {
            return Response()->json($valid->errors());
        }
        $myCart = Cart::where('fcm_token', '=', $request->header('fcm_token'))->with('product')->get();

        if ($myCart) {
           if($myCart->isEmpty()){
            $message = __('api.cartEmpty');
            return response()->json(['status' => false, 'code' => 202, 'message' => $message]);
        }

        $totalproduct = 0;
        foreach($myCart as $one) {
            $price =  ($one->product->price_offer)? $one->product->price_offer:$one->product->price;

            $totalproduct +=$price * $one->quantity;

        }

        $myCity=City::findOrFail($request->delivery_city_id);
        $promoCode=PromotionCode:: where('name',$request->get('promoCode_name'))->first();
         if($promoCode){
             $discount = ($totalproduct * $promoCode->discount)/100;
         }else { $discount =0 ;}
         
         
         
         $minOrder=$setting_minOrder->min_order;
            
        
         if(($totalproduct + $myCity->deliveryCost - $discount) < $minOrder ){
                $message = __('api.check_order').$minOrder." شيكل ";
                return response()->json(['status' => false, 'code' => 200, 'message' => $message]);
            }

        $order= new Order();
        $order->user_id= $user_id;
        $order->delivery_city_id=$request->delivery_city_id;
        $order->delivery_address=$request->delivery_address;
        $order->mobile=$request->mobile;
        $order->delivery_cost=($myCity->deliveryCost == 0)? 0:$myCity->deliveryCost;
        $order->discount_code=($promoCode)? $promoCode->discount:0;
        $order->code_name=($promoCode)? $promoCode->name:0;
        $order->total_price=$totalproduct + $myCity->deliveryCost - $discount;
        $order->save();

        if($order){

            foreach ($myCart as $one) {
                $ProductOrder = new OrderProduct();
                $ProductOrder->order_id = $order->id;
                $ProductOrder->product_id = $one->product_id;
                $ProductOrder->quantity = $one->quantity;
                $ProductOrder->discount = $one->product->discount;
                $ProductOrder->price =($one->product->price_offer)? $one->product->price_offer:$one->product->price;
                $ProductOrder->save();
            }
            
            Cart::where('fcm_token', '=', $request->header('fcm_token'))->delete();
        }
        $message = __('api.status1');
        return response()->json(['status' => true, 'code' => 200, 'message' => $message,
               'checkOut'=> ['phoneNumber'=>$request->mobile ,'totalProduct'=>$totalproduct ,'price_discount_code'=> $discount,'order'=>$order ,'myCart'=>$myCart ] ]);
    }
        else{
            $message = __('api.not_found');
            return response()->json(['status' => false, 'code' => 200, 'message' => $message]);

        }
        
    }
    else      // store is closed
    {
      $message = __('api.store_closed').date('h:i',strtotime($setting_minOrder->from_hour))." - ".date('h:i',strtotime($setting_minOrder->to_hour));
      return response()->json(['status' => false, 'code' => 200, 'message' => $message]);  
    }
    }

    public function checkPromo(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'name' => 'required',
            'date' => 'required',
        ]);
        if ($validator->fails()) {
            return Response()->json($validator->errors());
            
        }
        $promo = PromotionCode::where('name',$request->get('name'))->whereDate('end','>=', date('Y-m-d'))->whereDate('start','<=',date('Y-m-d'))->where('status','active')->first();
        if ($promo) {
            $message = __('api.ok');
            return response()->json(['status' => true, 'code' => 200, 'message' => $message , 'PromotionCode'=> $promo]);
        } else {
            $message = __('api.wrongPromo');
            return response()->json(['status' => false, 'code' => 200, 'message' => $message ]);
            
        }

    }
    
    public function deleteCartItems(Request $request){
        $myCart = Cart::where('fcm_token', '=', $request->header('fcm_token'))->delete();

        if($myCart){
            $message = __('api.ok');
            return response()->json(['status' => true, 'code' => 200, 'message' => $message]);
        }else{
            $message = __('api.not_found');
            return response()->json(['status' => true, 'code' => 200, 'message' => $message]);
        }

    }

    


}
