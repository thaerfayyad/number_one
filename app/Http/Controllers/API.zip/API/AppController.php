<?php
namespace App\Http\Controllers\API;
use App\Models\Ad;
use App\Models\Category;

use App\Models\Product;
use App\Models\Question;
use App\Models\City;
use App\Models\Cart;
use App\Models\Service;
use App\Models\AdditionService;
use App\Models\Page;
use App\Models\Contact;

use App\Http\Controllers\Controller;
use App\Models\Setting;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;


class AppController extends Controller
{


    public function getAds()
    {
        $data = Ad::query()->where('status', 'active')->get();
        if (count($data) > 0) {
            $message = __('api.ok');
            return response()->json(['status' => true, 'code' => 200, 'message' => $message, 'ads' => $data]);

        } else {
            $message = __('api.not_found');
            // return mainResponse(true, $message, $data, 200, 'items', '');
            return response()->json(['status' => true, 'code' => 200, 'message' => $message, 'ads' => $data]);

        }
    }

    public function getCities()
    {

        $cities = City::query()->where('status', 'active')->get();

        $message = __('api.ok');
        return response()->json(['status' => true, 'code' => 200, 'message' => $message, 'cities' => $cities]);
    }

    public function getCategories()
    {
        $categories = Category::query()->where('status', 'active')->get();
        $message = __('api.ok');
        return response()->json(['status' => true, 'code' => 200, 'message' => $message, 'categories' => $categories]);
    }

    public function allQuestions()
    {
        $questions = Question::query()->where('status', 'active')->get();
        $message = __('api.ok');
        return response()->json(['status' => true, 'code' => 200, 'message' => $message, 'questions' => $questions]);
    }

    public function getProductsByCategoryId($id, Request $request)
    {
        $products = Product::where('status', 'active')->where('category_id', $id)->orderBy('order','ASC')->paginate(16)->items();//get();
        foreach ($products as $one){

            $iscart =Cart::where('fcm_token', '=', $request->header('fcm_token'))->where('product_id', $one->id)->first();
            if($iscart){
                $one->is_cart=$iscart->quantity;
            }else{
                $one->is_cart='0';
            }
        }
        //$count_products=Cart::where('fcm_token', $request->header('fcm_token'))->count();
        $myCart = Cart::where('fcm_token', '=', $request->header('fcm_token'))->with('product')->get();
        $count_products = count($myCart);
        
        $total_cart = 0;
        foreach($myCart as $one) {
            $price =  ($one->product->price_offer)? $one->product->price_offer:$one->product->price;
            $total_cart +=$price * $one->quantity;
        }
        
        
        
        $message = __('api.ok');
        return response()->json(['status' => true, 'code' => 200, 'message' => $message, 'count_products'=>$count_products, 'total_cart'=>$total_cart,'products' => $products ]);
    }

    public function getOffers(Request $request)
    {
        $products = Product::where('status', 'active')->where('discount', '>', 0)->where('offer_from','<=', date('Y-m-d'))->where('offer_to','>=',date('Y-m-d'))->orderBy('order','ASC')->get();
        foreach ($products as $one) {

            $iscart = Cart::where('fcm_token', '=', $request->header('fcm_token'))->where('product_id', $one->id)->first();
            if ($iscart) {
                $one->is_cart = $iscart->quantity;
            } else {
                $one->is_cart = '0';
            }
        }
        $message = __('api.ok');
         return response()->json(['status' => true, 'code' => 200, 'message' => $message, 'offers' => $products]);


    }

    public function search(Request $request)
    {
        $items = Product::query();

        if ($request->has('text') && $request->text != '') {
            $items->whereHas('translations', function ($query) use ($request) {
                $query->where('locale', app()->getLocale())
                    ->where('name', 'like', '%' . $request->get('text') . '%');
            });

            $product = $items->where('status', 'active')->orderBy('order', 'ASC')->get();
            
            if (!$product->isEmpty()) {
                
                foreach ($product as $one){

                    $iscart =Cart::where('fcm_token', '=', $request->header('fcm_token'))->where('product_id', $one->id)->first();
                    if($iscart){
                        $one->is_cart=$iscart->quantity;
                    }else{
                        $one->is_cart='0';
                    }
                }
        
                $message = __('api.ok');
                return response()->json(['status' => true, 'code' => 200, 'message' => $message, 'products' => $product]);
            } else {
                $message = __('api.not_found');
                return response()->json(['status' => true, 'code' => 200, 'message' => $message]);
            }

        }


    }

    public function pages($id)
    {

        $page = Page::where('id',$id)->first();

        $message = __('api.ok');
        return response()->json(['status' => true, 'code' => 200, 'message' =>$message,'page'=>$page]);

    }

    public function getSetting()
    {

        $settings = Setting::query()->first();

        $message = __('api.ok');
        return response()->json(['status' => true, 'code' => 200, 'message' =>$message,'settings'=>$settings]);

    }

    public function contactUs(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'email' => 'required|email',
            'mobile' => 'required|digits_between:8,12',
            'name' => 'required',
            'message' => 'required',
            'type' => 'required',
        ]);
        if ($validator->fails()) {
            return response()->json(['status' => false, 'code' => 200, 'validator' => implode("\n", $validator->messages()->all())]);
        }

        $contact = new  Contact();
        $contact->email = $request->get('email');
        $contact->name = $request->get('name');
        $contact->mobile = $request->get('mobile');
        $contact->message = $request->get('message');
        $contact->type = $request->get('type');
        $contact->read = 0;
        $contact->save();


        $message = __('api.ok');

        return response()->json(['status' => true, 'code' => 200, 'message' => $message]);

    }
}







